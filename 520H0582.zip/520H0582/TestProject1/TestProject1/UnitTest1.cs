using StudentServiceLib;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private Student s;

        [TestInitialize]
        public void init()
        {
            s = new Student();
          
        }


        [TestMethod]
        public void WhenScoreIsBetterThan10_ResultFalse()
        {
            double sc = 11;
          
            Boolean result = false;
            try
            {
                s.Score = sc;
            }
            catch(SystemException)
            {
                    result = true;          
            }
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void WhenScoreIs10_ResultTrue()
        {
            double sc = 10;
            
            Boolean result = false;
            try
            {
                s.Score = sc;
            }
            catch (SystemException)
            {
                
                    result = true;
               
            }
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void WhenScoreIsWorseThan0_ResultFalse()
        {
            double sc = -1;
            Boolean result = false;
            try
            {
                s.Score = sc;
            }
            catch (SystemException)
            {
                    result = true;
            }
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void WhenScoreIs8_ResultA()
        {
            double sc = 8;
           
            s.Score = sc;
            char Letter = s.getLetterScore();


            Assert.AreEqual('A',Letter);
        }
        [TestMethod]
        public void WhenScoreIs7_ResultB()
        {
            double sc = 7;

            s.Score = sc;
            char Letter = s.getLetterScore();


            Assert.AreEqual('B', Letter);
        }
        [TestMethod]
        public void WhenScoreIs5_ResultC()
        {
            double sc = 5;

            s.Score = sc;
            char Letter = s.getLetterScore();


            Assert.AreEqual('C', Letter);
        }
        [TestMethod]
        public void WhenScoreIs3point5_ResultD()
        {
            double sc = 3.5;

            s.Score = sc;
            char Letter = s.getLetterScore();


            Assert.AreEqual('D', Letter);
        }
        [TestMethod]
        public void WhenScoreIsWorseThan3point5_ResultE()

        {
            double sc = 1;

            s.Score = sc;
            char Letter = s.getLetterScore();


            Assert.AreEqual('E', Letter);
        }

        [TestMethod]
        public void TestAddStudent()

        {   
            StudentService studentService = new StudentService();

            Student s1 = new Student();
            s1.Id = 1;
         

            Student s2 = new Student();
            s1.Id = 1;

            Boolean isFalse = false;
            studentService.addStudent(s1);
            
            if (studentService.addStudent(s2))
            {
                isFalse = true;
            };

            Assert.IsTrue(isFalse);
        }
    }
}